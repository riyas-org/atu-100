def bin_to_intel_hex(flash_bin, eeprom_bin, config_bin, output_hex):
    def add_hex_line(address, data, record_type=0):
        length = len(data)
        checksum = (length + (address >> 8) + (address & 0xFF) + record_type + sum(data)) & 0xFF
        checksum = (0x100 - checksum) & 0xFF
        return f":{length:02X}{address:04X}{record_type:02X}{''.join(f'{b:02X}' for b in data)}{checksum:02X}\n"

    with open(output_hex, 'w') as f:
        # 1. Process Flash Memory (Starting at 0x0000)
        with open(flash_bin, 'rb') as fb:
            data = fb.read()
            # PIC16 uses 2 bytes per word in HEX, address is word-based
            for i in range(0, len(data), 16):
                chunk = data[i:i+16]
                f.write(add_hex_line(i // 2, chunk))

        # 2. Process EEPROM (PIC16LF1938 EEPROM starts at word address 0xF000)
        with open(eeprom_bin, 'rb') as eb:
            data = eb.read()
            f.write(":020000040001F9\n") # Extended Linear Address Record for 0xF000
            for i in range(0, len(data), 16):
                chunk = data[i:i+16]
                f.write(add_hex_line(0xF000 + (i // 2), chunk))

        # 3. Process Config Bits (Located at 0x8007)
        with open(config_bin, 'rb') as cb:
            data = cb.read()
            f.write(":020000040000FA\n") # Reset to base address space
            f.write(add_hex_line(0x8007, data))

        f.write(":00000001FF\n") # End of File Record

    print(f"Successfully created {output_hex}")

# Usage
bin_to_intel_hex('_flash.bin', '_eeprom.bin', '_config.bin', 'restored_pic.hex')
