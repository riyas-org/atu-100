def bin_to_intel_hex_clean(flash_bin, eeprom_bin, config_bin, output_hex):
    def add_hex_line(address, data, record_type=0):
        length = len(data)
        checksum = (length + (address >> 8) + (address & 0xFF) + record_type + sum(data)) & 0xFF
        checksum = (0x100 - checksum) & 0xFF
        return f":{length:02X}{address:04X}{record_type:02X}{''.join(f'{b:02X}' for b in data)}{checksum:02X}\n"

    def get_clean_flash(filename):
        with open(filename, 'rb') as f:
            data = bytearray(f.read())
        
        # Step backward 2 bytes at a time (one PIC word)
        # to find where the real code ends and 0x3FFF padding begins
        end_index = len(data)
        while end_index >= 2:
            # Check for the 14-bit erased pattern (3F FF)
            # Adjust [end_index-2:end_index] == b'\xff\x3f' if endianness varies
            if data[end_index-2:end_index] == b'\xff\x3f':
                end_index -= 2
            else:
                break
        return data[:end_index]

    with open(output_hex, 'w') as f:
        # 1. Flash Memory - Now Truncated at the last real instruction
        flash_data = get_clean_flash(flash_bin)
        for i in range(0, len(flash_data), 16):
            chunk = flash_data[i:i+16]
            f.write(add_hex_line(i // 2, chunk))

        # 2. EEPROM - Truncated (starts with 0x52, then empty) [cite: 2]
        with open(eeprom_bin, 'rb') as eb:
            eeprom_data = eb.read().rstrip(b'\xff')
            if eeprom_data:
                f.write(":020000040001F9\n") 
                for i in range(0, len(eeprom_data), 16):
                    chunk = eeprom_data[i:i+16]
                    f.write(add_hex_line(0xF000 + (i // 2), chunk))

        # 3. Config Bits 
        with open(config_bin, 'rb') as cb:
            config_data = cb.read()
            f.write(":020000040000FA\n") 
            f.write(add_hex_line(0x8007, config_data))

        f.write(":00000001FF\n")

    print(f"Clean HEX created: {output_hex}")

bin_to_intel_hex_clean('_flash.bin', '_eeprom.bin', '_config.bin', 'clean_restored.hex')

